#dsgn270-a2
Owner/maintainer: Joel Kaye

##Attributions

Leeroy
Photo by <a href="https://stocksnap.io/author/374">Leeroy</a> from <a href="https://stocksnap.io">StockSnap</a>
https://stocksnap.io/license

Charles Forerunner
Photo by <a href="https://stocksnap.io/author/29066">Charles Forerunner</a> from <a href="https://stocksnap.io">StockSnap</a>
https://stocksnap.io/license

One Idea LLC
Photo by <a href="https://stocksnap.io/author/oneidea">One Idea LLC</a> from <a href="https://stocksnap.io">StockSnap</a>
https://stocksnap.io/license

Frank von Danwitz
https://images.freeimages.com/images/large-previews/5dd/man-camera-1477714.jpg
https://www.freeimages.com/license

Andre Carvalho
https://images.freeimages.com/images/large-previews/ae6/keyboard-spy-1242580.jpg
https://www.freeimages.com/license

Karolina Grabowska
https://kaboompics.com/photo/1440/white-chalkboard-writing
https://kaboompics.com/page/license-and-faq

carl dwyer
https://images.freeimages.com/images/large-previews/f38/people-at-work-1459248.jpg
https://www.freeimages.com/license

Charles Forerunner
https://cdn.stocksnap.io/img-thumbs/960w/office-work_HZCASACP3N.jpg
https://stocksnap.io/license


dlritter
https://images.freeimages.com/images/large-previews/62c/limelight-3-1188290.jpg
https://www.freeimages.com/license

B S K
https://images.freeimages.com/images/large-previews/bed/global-team-1238048.jpg
https://www.freeimages.com/license

